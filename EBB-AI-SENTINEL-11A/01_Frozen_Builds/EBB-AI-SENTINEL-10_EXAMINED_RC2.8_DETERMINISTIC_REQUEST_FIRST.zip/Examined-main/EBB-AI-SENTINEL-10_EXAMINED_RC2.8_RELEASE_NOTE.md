# EBB-AI-SENTINEL-10 — Examined Companion RC2.8 Release Note

Candidate identity: `examined-fall-2026-rc2.8-deterministic-request-first`

Failure-localized prompt-only patch over exact frozen RC2.7.

Added:
- Deterministic Request-First Contract — First-Position Count Execution
- Safety-Echo Provenance Gate — Actual Prior Safety State Required
- Literal-Fact Fallback — Sparse Mechanism / Burden / Decision Difficulty

Primary target: persistent Examined P09-A zero-option failure. Secondary targets: false-positive P12-A safety echoes and residual P01-B/P09-B evidence-minimal overreach.

The patch preserves the inherited RC2.7 Evidence-Minimal Output Contract, Safety-State Echo, Neutral-Question Rewrite Gate, RC2.6 safety envelope, post-safety clarification lock, count-binding contract and Examined count enforcement, occurrence-state controls, one-hop lock, clause-level evidence gate, and unsupported-mechanism deletion gate.

No endpoint, classifier, second model call, output postprocessor, application-side safety-completion token, storage field, or new user-data path is introduced.
