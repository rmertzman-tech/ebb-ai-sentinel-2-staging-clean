# EBB-AI-SENTINEL-5 — Examined RC2.3 Residual-Defect Candidate

Baseline: exact frozen SENTINEL-4 Examined RC2.2 candidate (SHA-256 `598523ff941275456e6f676a722ec35afd81418f0f2b0844f855a15ad780dfd5`).

Authorized changes: Companion instruction text, build identity, and this release note only.

RC2.3 makes four evidence-localized reinforcements after SENTINEL-4B:
1. **External Safety Completion Token:** a safety-controlled turn remains unresolved unless a separate system/application status field supplies `SAFETY_COMPLETION_CONFIRMED=TRUE`; user clarification, assistant language, or the tutor's own judgment cannot create the token or justify transition language.
2. **Occurrence-Noun Guard:** before using definite problem-state language, the tutor must verify that occurrence was actually established; concerns, aspirations, prevention conditions, and grammatical cues do not establish occurrence.
3. **Examined Count Enforcement:** a safe N-item request must visibly deliver exactly N items before any context question; a zero-item context request is explicitly invalid.
4. **Cross-Scenario Anti-Presupposition:** clean success, supported commitment, constrained commitment, and recurring burden may be explored only from supplied evidence; hidden threat, counterforce, coping function, blockage, or prior deficit may not be inserted as fact.

All RC2.2 safety, depletion, evidence-bound inference, proportionate-concern, constructive-sentinel, user-authority, and course-tool rules remain in force. General pattern-spotting or dark-coherence instructions are subordinate to the evidence rule.

No UI, storage, endpoint, profile flow, course-tool reference, mode system, response-completion guard, classifier, score, or context expansion is changed.

Candidate identity: `examined-fall-2026-rc2.3-residual-defect`.
