# EBB-AI-SENTINEL-9 — Navigator Twin RC2.7 Release Note

Candidate identity: `navigator-fall-2026-rc2.7-evidence-minimal-output`

Failure-localized prompt-only patch over frozen RC2.6.

Added:
- Evidence-Minimal Output Contract — No-Mechanism Default
- Safety-State Echo for unresolved post-safety clarification
- Neutral-Question Rewrite Gate — no model-supplied alternatives

The patch aims to prevent unsupported explanatory menus, mechanism glosses, and model-supplied question categories before emission. It preserves the inherited safety envelope, post-safety clarification lock, Navigator occurrence output guard, count contract, unsupported-mechanism gate, clause-level gate, question-symmetry check, one-hop lock, occurrence-state clamp, and fixed local immediate-danger behavior.

No endpoint, storage, application-side safety-completion token, classifier, second model call, output postprocessor, or new user-data path is introduced.
