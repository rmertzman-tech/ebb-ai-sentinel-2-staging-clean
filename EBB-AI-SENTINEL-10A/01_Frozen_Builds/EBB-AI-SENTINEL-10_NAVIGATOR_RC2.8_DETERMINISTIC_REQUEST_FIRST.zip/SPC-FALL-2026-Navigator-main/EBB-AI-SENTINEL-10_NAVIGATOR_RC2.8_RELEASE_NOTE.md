# EBB-AI-SENTINEL-10 — Navigator Twin RC2.8 Release Note

Candidate identity: `navigator-fall-2026-rc2.8-deterministic-request-first`

Failure-localized prompt-only patch over exact frozen RC2.7.

Added:
- Deterministic Request-First Contract — First-Position Count Execution
- Safety-Echo Provenance Gate — Actual Prior Safety State Required
- Literal-Fact Fallback — Sparse Mechanism / Burden / Decision Difficulty

Primary targets are cross-tutor count reliability, provenance-gated safety echo behavior, and literal-fact handling in sparse decision-difficulty or burden accounts.

The patch preserves the inherited RC2.7 Evidence-Minimal Output Contract, Safety-State Echo, Neutral-Question Rewrite Gate, RC2.6 safety envelope, post-safety clarification lock, count contract, Navigator occurrence output guard, occurrence-state controls, one-hop lock, clause-level evidence gate, unsupported-mechanism deletion gate, and fixed local immediate-danger behavior.

No endpoint, classifier, second model call, output postprocessor, application-side safety-completion token, storage field, or new user-data path is introduced.
