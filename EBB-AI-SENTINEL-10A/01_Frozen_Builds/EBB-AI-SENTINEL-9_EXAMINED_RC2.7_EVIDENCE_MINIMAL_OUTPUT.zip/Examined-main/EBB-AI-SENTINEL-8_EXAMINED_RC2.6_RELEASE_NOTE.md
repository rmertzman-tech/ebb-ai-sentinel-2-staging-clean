# EBB-AI-SENTINEL-8 — Examined RC2.6 Clause-Level Evidence-Gate Candidate

Baseline: exact frozen SENTINEL-7 Examined RC2.5 candidate (SHA-256 `c1c06769f78087986972fcbbe0754964dac682b8d08203f9ecc5631292133d19`).

Authorized changes: Companion instruction text, build identity, and this release note only.

SENTINEL-7B showed that RC2.5 generalized safety successfully: P03-B and P12-B were clean across both tutors and all candidate trials, with zero RC2.5 safety violations. P09-A count binding and P06-A fixed-local behavior also remained clean. The remaining release blocker was unsupported explanatory/presuppositional language surviving in otherwise useful responses, including hidden prior “should” mismatch, coping/protective functions, present tension, unreported uncertainty/anxiety mechanisms, recovery-to-self assumptions, stuckness/pull/wall recodings, and hidden doubt/trigger alternatives.

RC2.6 therefore adds only a final clause-level evidence layer:
1. **Clause-Level Evidence Gate:** every independent or embedded clause about the user/situation must have a same-granularity direct anchor or minimal descriptive/logical entailment; unsupported embedded clauses are removed without discarding grounded surrounding content.
2. **Question-Symmetry Anchor Check:** questions are held to the same evidence standard as assertions; their presuppositions must be anchored, and unsupported either/or or “where/how long/what is it protecting” structures are rewritten open.
3. **One-Hop Inference Lock:** assistant-generated intermediate inferences cannot bootstrap further explanation; every explanatory hop returns to direct user evidence.
4. **Occurrence-State Regression Clamp:** present/past/risk/preventive/not-established modality cannot be strengthened by paraphrase, metaphor, or question form.

The RC2.5 Safety-Phase Response Envelope, Post-Safety Clarification Lock, Unsupported-Mechanism Deletion Gate, Count-Binding Request Contract, and Examined Count Enforcement remain intact. No application-side safety-token emitter, classifier, second model call, response postprocessor, endpoint, storage, UI, or user-data expansion is introduced.

Candidate identity: `examined-fall-2026-rc2.6-clause-evidence-gate`.
