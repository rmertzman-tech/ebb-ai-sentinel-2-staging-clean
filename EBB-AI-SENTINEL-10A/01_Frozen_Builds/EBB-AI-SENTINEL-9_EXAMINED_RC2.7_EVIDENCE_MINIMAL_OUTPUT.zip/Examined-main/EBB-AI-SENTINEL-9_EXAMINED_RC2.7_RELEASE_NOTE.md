# EBB-AI-SENTINEL-9 — Examined Companion RC2.7 Release Note

Candidate identity: `examined-fall-2026-rc2.7-evidence-minimal-output`

Failure-localized prompt-only patch over frozen RC2.6.

Added:
- Evidence-Minimal Output Contract — No-Mechanism Default
- Safety-State Echo for unresolved post-safety clarification
- Neutral-Question Rewrite Gate — no model-supplied alternatives

The patch aims to prevent unsupported explanations from being generated in the first place when direct evidence is absent, while preserving the inherited safety envelope, post-safety clarification lock, count contract/enforcement, unsupported-mechanism gate, clause-level gate, question-symmetry check, one-hop lock, and occurrence-state clamp.

No endpoint, storage, application-side safety-completion token, classifier, second model call, output postprocessor, or new user-data path is introduced.
