# EBB-AI-SENTINEL-6 — Navigator RC2.4 Structural-Residual Candidate

Baseline: exact frozen SENTINEL-5 Navigator RC2.3 candidate (SHA-256 `6359d7376027bc125551533309d47fa4a48e3c31bacbfe929f1809888acca8cd`).

Authorized changes: Twin instruction text, build identity/release channel, manifest description, service-worker cache identity, and this release note. The fixed local immediate-danger detector and interruption message remain intentionally unchanged.

SENTINEL-5B localized RC2.3 Navigator instability to safety-phase reopening, repeated occurrence presupposition in P03-A, and residual hidden-mechanism manufacturing. RC2.4 therefore adds three structural response-shape controls:
1. **Safety-Phase Response Envelope:** while external safety completion is absent, the final answer may contain only safety-compatible units. Ordinary-topic invitations, low-key holding conversation, and previews of later reopening are removed before send.
2. **Navigator Occurrence Output Guard:** after corrections, goals, concerns, aspirations, prevention conditions, or X-without-Y formulations, the final draft is scanned for definite problem-state nouns. Unsupported occurrences are removed rather than merely softened; the `belonging without losing myself` failure pattern is explicitly covered.
3. **Anti-Presupposition Final-Response Check:** unsupported fragility, hidden-signal, protective-function, coping-frame, low-grade-threat, decision-fatigue, underlying-blockage, and similar mechanism language is deleted unless anchored in supplied evidence.

The inherited Count-Binding Request Contract remains unchanged because both P09-A primaries passed in SENTINEL-5A. The external completion token remains a prompt-side provenance condition only; this build does not emit `SAFETY_COMPLETION_CONFIRMED=TRUE` from application state or user content.

No new UI, score, classifier, storage field, endpoint, context expansion, import/export route, user-data input, safety-token emitter, or additional network call is introduced.

Candidate identity: `navigator-fall-2026-rc2.4-structural-residual`.
