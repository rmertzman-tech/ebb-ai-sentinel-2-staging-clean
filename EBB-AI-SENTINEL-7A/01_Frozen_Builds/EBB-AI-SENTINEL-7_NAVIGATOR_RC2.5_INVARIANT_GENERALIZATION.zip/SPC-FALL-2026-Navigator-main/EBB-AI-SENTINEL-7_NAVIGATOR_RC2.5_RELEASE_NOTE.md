# EBB-AI-SENTINEL-7 — Navigator RC2.5 Invariant-Generalization Candidate

Baseline: exact frozen SENTINEL-6 Navigator RC2.4 candidate (SHA-256 `6792f7ee33b702631a1bfb595b43ec12f032900b81a2afb6feda5b208ddbbb75`).

Authorized changes: Twin instruction text, build identity/release metadata, service-worker cache identity, and this release note. The fixed local immediate-danger detector and interruption message remain unchanged.

SENTINEL-6B showed that Navigator's focal P03-A occurrence guard was clean 4/4 and P03-B safety-envelope behavior was clean across all candidate trials. The remaining safety failure occurred on a different post-safety clarification route (P12-B), while residual manufacturing persisted across success, burden, constrained commitment, recurring-cost, and sparse-change cases.

RC2.5 adds only:
1. **Post-Safety Clarification Lock:** user clarification can revise meaning but never supplies safety completion. If an earlier safety phase is active and the external completion token is absent, the response remains inside the existing Safety-Phase Response Envelope regardless of reassurance, correction, disagreement, or apparent calm.
2. **Unsupported-Mechanism Deletion Gate:** every hidden-state/mechanism claim and every presupposing question requires a direct user-provided anchor. Unsupported second-layer explanations are deleted and rewritten around observable sequence, supplied terms, and non-presupposing questions.

The Navigator Occurrence Output Guard, Count-Binding Request Contract, P06-A fixed local safety behavior, endpoint, storage model, import/export paths, and all network behavior are preserved. The external token remains prompt-side only; this build does not emit `SAFETY_COMPLETION_CONFIRMED=TRUE`.

Candidate identity: `navigator-fall-2026-rc2.5-invariant-generalization`.
