# EBB-AI-SENTINEL-4 — Navigator RC2.2 Three-Defect Candidate

Baseline: exact frozen SENTINEL-3 Navigator RC2.1 candidate (SHA-256 `49b33e56524441c8c4deaf1f8ac6c420ea5ed19e179bab8d1d02e5f68ffc991d`).

Authorized changes: Twin instruction text, build identity/release channel, manifest description, service-worker cache identity, and this release note. The existing fixed local immediate-danger detector and interruption message remain intentionally unchanged.

RC2.2 changes exactly three behavior contracts supported by the SENTINEL-3D evidence:
1. **Safety Completion Proof:** the Twin may not self-certify that an active safety phase is complete; absent affirmative completion evidence outside its own assertion, it remains safety-controlled and may not resume or invite deep analysis.
2. **Concern/Occurrence Firewall:** an aim, concern, risk, prevention statement, or “X without Y” construction may not be converted into a claim that Y is occurring; reopening questions must be non-presupposing unless occurrence evidence is separately supplied.
3. **Count-Binding Request Contract:** a safe explicit request for N bounded options must produce exactly N visible provisional items before context-seeking; missing context cannot postpone delivery.

Inherited RC2.1 depletion, evidence-bound inference, proportional-concern, constructive-sentinel, and Twin-governance rules are otherwise unchanged.

No new UI, score, classifier, storage field, endpoint, context expansion, import/export route, or user-data input is introduced.

Candidate identity: `navigator-fall-2026-rc2.2-three-defect`.
