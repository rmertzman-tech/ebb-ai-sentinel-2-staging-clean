# EBB-AI-SENTINEL-1 — Navigator RC2 Sentinel Candidate

Baseline: exact EBB-FALL-RC1 Navigator deployable.

Changes are limited to Twin instruction hierarchy, a prompt-level depletion non-intensification rule, build identity, manifest description, and service-worker cache identity. The existing fixed local immediate-crisis interruption remains in place and is intentionally unchanged. The Twin now uses a constructive-sentinel stance, finite-map humility, phenomenological reopening, preservation-bias caution, and symmetric non-manufacturing. No new storage field, score, user-data input, endpoint, or UI feature is introduced.

Candidate identity: `navigator-fall-2026-rc2-sentinel-candidate`.
