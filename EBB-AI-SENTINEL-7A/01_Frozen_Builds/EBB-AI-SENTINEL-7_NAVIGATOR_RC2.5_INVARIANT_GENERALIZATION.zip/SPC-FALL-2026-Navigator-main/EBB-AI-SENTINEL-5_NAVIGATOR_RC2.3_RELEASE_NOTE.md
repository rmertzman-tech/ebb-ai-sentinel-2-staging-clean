# EBB-AI-SENTINEL-5 — Navigator RC2.3 Residual-Defect Candidate

Baseline: exact frozen SENTINEL-4 Navigator RC2.2 candidate (SHA-256 `2ce8f8e33c787b0acd19633e1bcb15cda055d6e28c28e862d863180801204255`).

Authorized changes: Twin instruction text, build identity/release channel, manifest description, service-worker cache identity, and this release note. The existing fixed local immediate-danger detector and interruption message remain intentionally unchanged.

RC2.3 makes three shared evidence-localized reinforcements after SENTINEL-4B while retaining Navigator's already-successful count behavior:
1. **External Safety Completion Token:** a safety-controlled turn remains unresolved unless a separate system/application status field supplies `SAFETY_COMPLETION_CONFIRMED=TRUE`; user clarification, assistant language, or the Twin's own judgment cannot create the token or justify transition language.
2. **Occurrence-Noun Guard:** definite problem-state nouns require occurrence evidence; concern, aspiration, risk, prevention language, and grammatical cues do not establish current occurrence.
3. **Cross-Scenario Anti-Presupposition:** clean success, supported commitment, constrained commitment, and recurring burden may be explored only from supplied evidence; hidden threat, counterforce, coping function, blockage, or prior deficit may not be inserted as fact.

The inherited Count-Binding Request Contract remains unchanged for Navigator because SENTINEL-4B showed its P09-A behavior already meeting the count contract.

All RC2.2 safety, depletion, evidence-bound inference, proportionate-concern, constructive-sentinel, user-authority, and Twin-governance rules remain in force. General pattern-spotting or dark-coherence instructions are subordinate to the evidence rule.

No new UI, score, classifier, storage field, endpoint, context expansion, import/export route, or user-data input is introduced.

Candidate identity: `navigator-fall-2026-rc2.3-residual-defect`.
