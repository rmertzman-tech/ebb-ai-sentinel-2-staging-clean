# EBB-AI-SENTINEL-3 — Navigator RC2.1 Failure-Localized Candidate

Baseline: exact frozen SENTINEL-2 Navigator RC2 candidate (SHA-256 `09e215fec74b6f6850b5fa943032c3252a3198198eeb49bdf84483f1e4e62303`).

Authorized changes: Twin instruction text, build identity/release channel, manifest description, service-worker cache identity, and this release note. The existing fixed local immediate-danger detector and interruption message remain intentionally unchanged.

The patch adds safety phase-lock, depletion minimality, evidence-bound inference, reopening-without-replacement, explicit-request compliance, and mechanism-first proportional concern. No new UI, score, classifier, storage field, endpoint, context expansion, import/export route, or user-data input is introduced.

Candidate identity: `navigator-fall-2026-rc2.1-failure-localized`.
