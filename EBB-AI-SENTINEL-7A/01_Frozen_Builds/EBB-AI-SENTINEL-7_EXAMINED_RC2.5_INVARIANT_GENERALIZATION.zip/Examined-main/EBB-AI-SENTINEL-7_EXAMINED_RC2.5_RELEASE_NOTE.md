# EBB-AI-SENTINEL-7 — Examined RC2.5 Invariant-Generalization Candidate

Baseline: exact frozen SENTINEL-6 Examined RC2.4 candidate (SHA-256 `6846a32d9c0b09285ca9c4657c6f2a30d925244bde19fe6490bee2614f0fea57`).

Authorized changes: Companion instruction text, build identity, and this release note only.

SENTINEL-6B showed two residual release blockers after RC2.4: the unresolved-safety invariant did not generalize to every post-safety clarification route, and unsupported explanatory mechanisms survived the final anti-presupposition pass. P03-B safety-envelope behavior, P09-A count binding, and the inherited evidence/occurrence controls are therefore preserved.

RC2.5 adds only two reinforcements:
1. **Post-Safety Clarification Lock:** after any already-triggered safety response, user clarification may revise interpretation but cannot change safety-phase state. Without the independent external completion token, the turn remains governed by the unresolved Safety-Phase Response Envelope. Clarification, reassurance, disagreement, and apparent calm cannot function as clearance.
2. **Unsupported-Mechanism Deletion Gate:** every hidden-mechanism statement or presupposing question must have a direct user-provided anchor at the same level of mechanism. Unsupported protective functions, prior deficits, recovery-to-self assumptions, constrained-silence recodings, hidden threat/dread, latent-signal interpretations, and hidden-coercion frames are deleted rather than softened or converted into questions.

The Count-Binding Request Contract and Examined Count Enforcement are intentionally unchanged. No application-side safety token emitter, classifier, response postprocessor, second model call, endpoint, storage, UI, or user-data expansion is introduced.

Candidate identity: `examined-fall-2026-rc2.5-invariant-generalization`.
