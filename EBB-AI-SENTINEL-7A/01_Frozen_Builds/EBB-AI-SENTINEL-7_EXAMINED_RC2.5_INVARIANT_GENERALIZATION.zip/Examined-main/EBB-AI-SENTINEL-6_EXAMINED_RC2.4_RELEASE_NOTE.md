# EBB-AI-SENTINEL-6 — Examined RC2.4 Structural-Residual Candidate

Baseline: exact frozen SENTINEL-5 Examined RC2.3 candidate (SHA-256 `0f974d82daba8ed6847cd050d23d33339ebd3d07c069ff153faf58c0b4f84110`).

Authorized changes: Companion instruction text, build identity, and this release note only.

RC2.4 is deliberately narrower than RC2.3. SENTINEL-5B showed that count enforcement closed, primary performance reached 44/48 with zero primary FAIL, and remaining release-blocking defects were concentrated in safety-phase leakage, Navigator occurrence presupposition, and residual hidden-mechanism manufacturing.

Examined receives two structural response-shape reinforcements while preserving the RC2.3 external-token, occurrence, count, evidence, and safety rules:
1. **Safety-Phase Response Envelope:** while an external completion token is absent, the answer is restricted to safety-compatible units only. Ordinary-topic invitations, holding-pattern conversation, and previews of later reopening are deleted in a final envelope check.
2. **Anti-Presupposition Final-Response Check:** before sending, unsupported hidden conditions/mechanisms are removed rather than merely softened into speculative language. Clean success, supported commitment, constrained commitment, sparse change, and recurring burden each receive explicit response-shape rules.

The Examined Count Enforcement block is retained byte-for-byte from RC2.3 because P09-A passed in SENTINEL-5A. The shared Occurrence-Noun Guard is also retained; the additional Navigator-only occurrence output guard is not added to Examined because Examined P03-A was stable across all RC2.3 trials.

No UI, storage, endpoint, profile flow, course-tool reference, mode system, classifier, score, context expansion, safety-token emitter, or request-routing change is introduced.

Candidate identity: `examined-fall-2026-rc2.4-structural-residual`.
