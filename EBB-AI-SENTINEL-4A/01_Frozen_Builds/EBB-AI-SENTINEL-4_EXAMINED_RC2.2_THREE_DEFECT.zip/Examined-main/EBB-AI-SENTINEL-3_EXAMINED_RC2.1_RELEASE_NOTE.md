# EBB-AI-SENTINEL-3 — Examined RC2.1 Failure-Localized Candidate

Baseline: exact frozen SENTINEL-2 Examined RC2 candidate (SHA-256 `8cef138c4407923df638b127a60d9a0d463b044fd96b87b062761d599591f00f`).

Authorized changes: Companion instruction text, build identity, and this release note. The patch adds safety phase-lock, depletion minimality, evidence-bound inference, reopening-without-replacement, explicit-request compliance, and mechanism-first proportional concern. It removes the acute-depletion instruction to validate “low coherence” and instead requires concrete user-language.

No UI, storage, endpoint, profile flow, course-tool reference, mode system, or response-completion guard is changed.

Candidate identity: `examined-fall-2026-rc2.1-failure-localized`.
