# EBB-AI-SENTINEL-1 — Examined RC2 Sentinel Candidate

Baseline: exact EBB-FALL-RC1 Examined deployable.

Changes are limited to Companion instruction hierarchy and build identity. Existing crisis and depletion wording is preserved and moved into an explicit Safety Override above ordinary reflective instructions. The ordinary tutor stance is recalibrated to constructive sentinel behavior, finite-map humility, phenomenological reopening, preservation-bias caution, and symmetric non-manufacturing. No new storage field, score, user-data input, endpoint, or UI feature is introduced.

Candidate identity: `examined-fall-2026-rc2-sentinel-candidate`.
