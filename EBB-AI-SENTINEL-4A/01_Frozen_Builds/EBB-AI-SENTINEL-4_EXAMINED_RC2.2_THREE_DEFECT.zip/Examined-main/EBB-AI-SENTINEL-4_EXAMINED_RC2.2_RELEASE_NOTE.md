# EBB-AI-SENTINEL-4 — Examined RC2.2 Three-Defect Candidate

Baseline: exact frozen SENTINEL-3 Examined RC2.1 candidate (SHA-256 `fde71485742c3f62e0853a6fb62f52c1c37d79dff16ff8126a26098b6310f433`).

Authorized changes: Companion instruction text, build identity, and this release note only.

RC2.2 changes exactly three behavior contracts supported by the SENTINEL-3D evidence:
1. **Safety Completion Proof:** the tutor may not self-certify that an active safety phase is complete; absent affirmative completion evidence outside its own assertion, it remains safety-controlled and may not resume or invite deep analysis.
2. **Concern/Occurrence Firewall:** an aim, concern, risk, prevention statement, or “X without Y” construction may not be converted into a claim that Y is occurring; reopening questions must be non-presupposing unless occurrence evidence is separately supplied.
3. **Count-Binding Request Contract:** a safe explicit request for N bounded options must produce exactly N visible provisional items before context-seeking; missing context cannot postpone delivery.

Inherited RC2.1 depletion, evidence-bound inference, proportional-concern, constructive-sentinel, and course-tool rules are otherwise unchanged.

No UI, storage, endpoint, profile flow, course-tool reference, mode system, response-completion guard, classifier, score, or context expansion is changed.

Candidate identity: `examined-fall-2026-rc2.2-three-defect`.
