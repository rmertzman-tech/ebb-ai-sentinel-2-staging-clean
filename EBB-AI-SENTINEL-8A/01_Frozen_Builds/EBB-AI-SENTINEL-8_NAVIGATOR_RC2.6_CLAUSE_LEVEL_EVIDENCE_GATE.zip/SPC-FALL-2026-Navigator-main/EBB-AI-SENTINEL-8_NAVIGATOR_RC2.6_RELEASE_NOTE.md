# EBB-AI-SENTINEL-8 — Navigator RC2.6 Clause-Level Evidence-Gate Candidate

Baseline: exact frozen SENTINEL-7 Navigator RC2.5 candidate (SHA-256 `67312af0bbee3411de478cff17657273d6f05c5dcb87b45f5e86ad0a2c40a198`).

Authorized changes: Twin instruction text, build identity/release metadata, service-worker cache identity, and this release note. The fixed local immediate-danger detector and interruption message remain unchanged.

SENTINEL-7B showed zero RC2.5 safety violations, with P03-B and P12-B clean across all candidate trials, while P09-A count binding and P06-A fixed-local behavior remained clean. Residual manufacturing was localized to clause/question leakage: current tension inferred from an aspiration, difficulty recoded as stuckness/pull/wall, recovery states inferred from sleep/meal burden, hidden “should” mismatch inferred from successful structure, and other second-layer mechanisms without direct anchors.

RC2.6 adds four final-emission checks:
1. **Clause-Level Evidence Gate:** every clause, including subordinate and parenthetical clauses, must have a same-granularity direct anchor or minimal descriptive/logical entailment.
2. **Question-Symmetry Anchor Check:** a question may not presuppose a state or mechanism that an assertion could not state. Unsupported problem-shaped alternatives are replaced with open questions at the user’s evidential level.
3. **One-Hop Inference Lock:** assistant-introduced intermediate explanations cannot become evidence for later claims; explanatory chains must return to direct user anchors.
4. **Occurrence-State Regression Clamp:** PRESENT/PAST/RISK/PREVENTIVE/NOT-ESTABLISHED status cannot be strengthened through wording or question form.

The Navigator Occurrence Output Guard, RC2.5 Safety-Phase Response Envelope and Post-Safety Clarification Lock, Count-Binding Request Contract, P06-A fixed local safety behavior, endpoint, storage model, import/export paths, and network behavior are preserved. The external completion token remains prompt-side only.

Candidate identity: `navigator-fall-2026-rc2.6-clause-evidence-gate`.
